
class PlayRset(object):
    """游戏分数记录"""
    _score = 0 # 总分
    _life = 3 # 生命数量
    _blood = 1000 # 生命值

    @property
    def score(self):
        return self._score

    @score.setter
    def score(self, value):
        if value < 0 :
            pass
        else:
            self._score = value